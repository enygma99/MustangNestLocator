select * from review;

select * from review;

select * from apartment;

select * from usertable;
